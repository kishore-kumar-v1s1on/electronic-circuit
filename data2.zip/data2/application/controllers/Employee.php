<?php
class Employee extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model("Employee_model");
        $this->load->helper(["form", "url"]);
    }

    public function index() {
        $this->load->view("employee_view");
    }

    public function fetchEmployees() {
        $employees = $this->Employee_model->getAllEmployees();
        echo json_encode($employees);
    }

    public function saveEmployee() {
        $config["upload_path"] = "./uploads/";
        $config["allowed_types"] = "jpg|jpeg|png|gif";
        $this->load->library("upload", $config);

        if (!$this->upload->do_upload("image")) {
            $imagePath = "";
        } else {
            $imageData = $this->upload->data();
            $imagePath = "uploads/" . $imageData["file_name"];
        }

        $data = [
            "name" => $this->input->post("name"),
            "age" => $this->input->post("age"),
            "dob" => $this->input->post("dob"),
            "gender" => $this->input->post("gender"),
            "department" => $this->input->post("department"),
            "skills" => implode(",", $this->input->post("skills")),
            "image" => $imagePath
        ];

        if ($this->input->post("id")) {
            $this->Employee_model->updateEmployee($this->input->post("id"), $data);
        } else {
            $this->Employee_model->insertEmployee($data);
        }

        echo json_encode(["status" => "success"]);
    }

    public function editEmployee($id) {
        $employee = $this->Employee_model->getEmployeeById($id);
        echo json_encode($employee);
    }

    public function deleteEmployee($id) {
        $this->Employee_model->deleteEmployee($id);
        echo json_encode(["status" => "success"]);
    }
}
?>
