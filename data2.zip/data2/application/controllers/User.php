<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('users_model');
		//include modal.php in views
		$this->inc['modal'] = $this->load->view('modal', '', true);
	}
	public function index(){
		$this->load->view('show', $this->inc);
	}

	public function show(){
		$data = $this->users_model->show();
		$output = array();
		foreach($data as $row){
			?>
			<tr>
				<td><?php echo $row->id; ?></td>
				<td><?php echo $row->fname; ?></td>
				<td><?php echo $row->lname; ?></td>
				<td><?php echo $row->email; ?></td>
				<td><?php echo $row->gender; ?></td>
				<td><?php echo $row->skills; ?></td>
				<td><?php echo $row->cars; ?></td>
				<td><?php echo $row->birthday; ?></td>
				<td>
					<button class="btn btn-warning edit" data-id="<?php echo $row->id; ?>"><span class="glyphicon glyphicon-edit"></span> Edit</button> || 
					<button class="btn btn-danger delete" data-id="<?php echo $row->id; ?>"><span class="glyphicon glyphicon-trash"></span> Delete</button>
				</td>
			</tr>
			<?php
		}
	}

	public function insert(){		
		$user['fname'] = $_POST['fname'];
		$user['lname'] = $_POST['lname'];
		$user['email'] = $_POST['email'];		
		$user['gender'] = $_POST['gender'];		
		$user['skills'] = $_POST['skills'];		
		$user['cars'] = $_POST['cars'];		
		$user['birthday'] = $_POST['birthday'];		
		$query = $this->users_model->insert($user);
	}

	public function getuser(){
		$id = $_POST['id'];
		$data = $this->users_model->getuser($id);
		echo json_encode($data);
	}

	public function update(){
		$id = $_POST['id'];
		$user['fname'] = $_POST['fname'];
		$user['lname'] = $_POST['lname'];
		$user['email'] = $_POST['email'];
		$user['gender'] = $_POST['gender'];
		$user['skills'] = $_POST['skills'];
		$user['cars'] = $_POST['cars'];
		$user['birthday'] = $_POST['birthday'];

		$query = $this->users_model->updateuser($user, $id);
	}

	public function delete(){
		$id = $_POST['id'];
		$query = $this->users_model->delete($id);
	}

}
