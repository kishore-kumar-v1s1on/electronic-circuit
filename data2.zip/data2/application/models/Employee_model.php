<?php
class Employee_model extends CI_Model {
    public function getAllEmployees() {
        return $this->db->get("employees")->result();
    }

    public function insertEmployee($data) {
        return $this->db->insert("employees", $data);
    }

    public function getEmployeeById($id) {
        return $this->db->get_where("employees", ["id" => $id])->row();
    }

    public function updateEmployee($id, $data) {
        return $this->db->where("id", $id)->update("employees", $data);
    }

    public function deleteEmployee($id) {
        return $this->db->where("id", $id)->delete("employees");
    }
}
?>
