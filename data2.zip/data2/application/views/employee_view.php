<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Employee Management</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center">Employee Management</h2>
        <button class="btn btn-success mb-3" onclick="showModal()">Add Employee</button>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Age</th>
                    <th>DOB</th>
                    <th>Gender</th>
                    <th>Department</th>
                    <th>Skills</th>
                    <th>Image</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="employeeTable"></tbody>
        </table>
    </div>

    <!-- Employee Modal -->
    <div class="modal fade" id="employeeModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Employee Form</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <form id="employeeForm">
                        <input type="hidden" id="id" name="id">
                        <label>Name:</label>
                        <input type="text" name="name" id="name" class="form-control" required>
                        <label>Age:</label>
                        <input type="number" name="age" id="age" class="form-control" required>
                        <label>Date of Birth:</label>
                        <input type="date" name="dob" id="dob" class="form-control" required>
                        <label>Gender:</label>
                        <select name="gender" id="gender" class="form-control">
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Other">Other</option>
                        </select>
                        <label>Department:</label>
                        <input type="text" name="department" id="department" class="form-control">
                        <label>Skills:</label>
                        <input type="checkbox" name="skills[]" value="PHP"> PHP
                        <input type="checkbox" name="skills[]" value="JavaScript"> JavaScript
                        <input type="checkbox" name="skills[]" value="Python"> Python
                        <label>Image:</label>
                        <input type="file" name="image" id="image" class="form-control">
                        <br>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        function showModal() {
            $("#employeeModal").modal("show");
            $("#employeeForm")[0].reset();
            $("#id").val("");
        }

        $("#employeeForm").submit(function(e) {
            e.preventDefault();
            $.ajax({
                url: "<?= base_url('employee/saveEmployee') ?>",
                type: "POST",
                data: new FormData(this),
                processData: false,
                contentType: false,
                success: function() {
                    $("#employeeModal").modal("hide");
                    location.reload();
                }
            });
        });

        function editEmployee(id) {
            $.get("<?= base_url('employee/editEmployee/') ?>" + id, function(data) {
                let emp = JSON.parse(data);
                $("#id").val(emp.id);
                $("#name").val(emp.name);
                $("#age").val(emp.age);
                $("#dob").val(emp.dob);
                $("#gender").val(emp.gender);
                $("#department").val(emp.department);
                $("#employeeModal").modal("show");
            });
        }

        function deleteEmployee(id) {
            $.post("<?= base_url('employee/deleteEmployee/') ?>" + id, function() {
                location.reload();
            });
        }
    </script>
</body>
</html>
