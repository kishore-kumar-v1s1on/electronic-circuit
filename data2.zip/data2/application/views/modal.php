<!-- Add New -->
<div class="modal fade" id="addnew" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel">Add New Member</h4></center>
            </div>
            <div class="modal-body">
			<div class="container-fluid">
			<form id="addForm">
				<div class="row">
					<div class="col-md-3">
						<label class="control-label" style="position:relative; top:7px;">First Name:</label>
					</div>
					<div class="col-md-9">
						<input type="text" class="form-control" name="fname" required>
					</div>
				</div>
				<div style="height:10px;"></div>
				<div class="row">
					<div class="col-md-3">
						<label class="control-label" style="position:relative; top:7px;">Last Name:</label>
					</div>
					<div class="col-md-9">
						<input type="text" class="form-control" name="lname" required>
					</div>
				</div>
				<div style="height:10px;"></div>
				<div class="row">
					<div class="col-md-3">
						<label class="control-label" style="position:relative; top:7px;">Email:</label>
					</div>
					<div class="col-md-9">
						<input type="email" class="form-control" name="email" required>
					</div>
				</div>
				<div style="height:10px;"></div>
				<div class="row">
					<div class="col-md-3">
						<label class="control-label" style="position:relative; top:7px;">Gender:</label>
					</div>
					<div class="col-md-9">
						<!-- <input type="email" class="form-control" name="email" required> -->
						<input type="radio" id="gender1" name="gender" class="custom-control-input" value="Male" required >
                        <label class="custom-control-label" for="gender1">Male</label>
                        <input type="radio" id="gender2" name="gender" class="custom-control-input" value="Female" >
                        <label class="custom-control-label" for="gender2">Female</label>
					</div>
				</div>
				<div style="height:10px;"></div>
				<div class="row">
					<div class="col-md-3">
						<label class="control-label" style="position:relative; top:7px;">Skills:</label>
					</div>
					<div class="col-md-9">
						<input type="checkbox" id="skills1" name="skills" value="Php" required >
						<label for="skills1">PHP</label><br>
						<input type="checkbox" id="skills2" name="skills" value="Java">
						<label for="skills2">JAVA</label><br>
						<input type="checkbox" id="skills3" name="skills" value="Python">
						<label for="skills3">PYTHON</label><br><br>
					</div>
				</div>
				<div style="height:10px;"></div>
				<div class="row">
					<div class="col-md-3">
						<label class="control-label" style="position:relative; top:7px;">Country:</label>
					</div>
					<div class="col-md-9">
						<select name="cars" id="cars">
							<option value="volvo" required>Volvo</option>
							<option value="saab">Saab</option>
							<option value="opel">Opel</option>
							<option value="audi">Audi</option>
						</select>
					</div>
				</div>
				<div style="height:10px;"></div>
				<div class="row">
					<div class="col-md-3">
						<label class="control-label" style="position:relative; top:7px;">Date:</label>
					</div>
					<div class="col-md-9">
						<input type="date" class="form-control" id="birthday" name="birthday" required>
					</div>
				</div>
				 
				
            </div> 
			</div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                <button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-floppy-disk"></span> Save</a>
			</form>
            </div>
			
        </div>
    </div>
</div>

<!-- Edit -->
<div class="modal fade" id="editmodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel">Edit Member</h4></center>
            </div>
            <div class="modal-body">
			<div class="container-fluid">
			<form id="editForm">
				<div class="row">
					<div class="col-md-3">
						<label class="control-label" style="position:relative; top:7px;">First Name:</label>
					</div>
					<div class="col-md-9">
						<input type="text" class="form-control" name="fname" id="fname">
					</div>
				</div>
				<div style="height:10px;"></div>
				<div class="row">
					<div class="col-md-3">
						<label class="control-label" style="position:relative; top:7px;">Last Name:</label>
					</div>
					<div class="col-md-9">
						<input type="text" class="form-control" name="lname" id="lname">
					</div>
				</div>
				<div style="height:10px;"></div>
				<div class="row">
					<div class="col-md-3">
						<label class="control-label" style="position:relative; top:7px;">Email:</label>
					</div>
					<div class="col-md-9">
						<input type="text" class="form-control" name="email" id="email">
					</div>
				</div>
				<div style="height:10px;"></div>
				<div class="row">
					<div class="col-md-3">
						<label class="control-label" style="position:relative; top:7px;">Gender:</label>
					</div>
					<div class="col-md-9">
						<input type="radio" id="gender1" name="gender" class="custom-control-input" value="Male" required >
                        <label class="custom-control-label" for="gender1">Male</label>
                        <input type="radio" id="gender2" name="gender" class="custom-control-input" value="Female" >
                        <label class="custom-control-label" for="gender2">Female</label>
					</div>
				</div>
				<div style="height:10px;"></div>
				<div class="row">
					<div class="col-md-3">
						<label class="control-label" style="position:relative; top:7px;">Skills:</label>
					</div>
					<div class="col-md-9">
						<input type="checkbox" id="skills1" name="skills" value="Php" required >
						<label for="skills1">PHP</label><br>
						<input type="checkbox" id="skills2" name="skills" value="Java">
						<label for="skills2">JAVA</label><br>
						<input type="checkbox" id="skills3" name="skills" value="Python">
						<label for="skills3">PYTHON</label><br><br>
					</div>
				</div>
				<div style="height:10px;"></div>
				<div class="row">
					<div class="col-md-3">
						<label class="control-label" style="position:relative; top:7px;">Vehicle:</label>
					</div>
					<div class="col-md-9">
						<select name="cars" id="cars">
							<option value="volvo">Volvo</option>
							<option value="saab">Saab</option>
							<option value="opel">Opel</option>
							<option value="audi">Audi</option>
						</select>
					</div>
				</div>
				<div style="height:10px;"></div>
				<div class="row">
					<div class="col-md-3">
						<label class="control-label" style="position:relative; top:7px;">Date:</label>
					</div>
					<div class="col-md-9">
						<input type="date" class="form-control" id="birthday" name="birthday" required>
					</div>
				</div>
				<input type="hidden" name="id" id="userid">
            </div> 
			</div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                <button type="submit" class="btn btn-warning"><span class="glyphicon glyphicon-check"></span> Update</a>
			</form>
            </div>
			
        </div>
    </div>
</div>

<!-- Delete -->
<div class="modal fade" id="delmodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel">Delete Member</h4></center>
            </div>
            <div class="modal-body">
				<h4 class="text-center">Are you sure you want to delete</h4>
				<h2 id="delfname" class="text-center"></h2>
			</div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                <button type="button" id="delid" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Yes</button>
            </div>
			
        </div>
    </div>
</div>
